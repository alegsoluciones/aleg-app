/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: appointments
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `appointments` (
  `id` varchar(36) NOT NULL,
  `start` timestamp NOT NULL,
  `end` timestamp NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `notes` text,
  `status` enum(
  'PENDING',
  'CONFIRMED',
  'COMPLETED',
  'CANCELLED',
  'IN_PROGRESS'
  ) NOT NULL DEFAULT 'PENDING',
  `type` enum('CONSULTATION', 'CONTROL', 'SURGERY', 'OTHER') NOT NULL DEFAULT 'CONSULTATION',
  `reminderSent` tinyint NOT NULL DEFAULT '0',
  `createdAt` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updatedAt` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  `tenantId` varchar(36) DEFAULT NULL,
  `patientId` varchar(36) DEFAULT NULL,
  `doctorId` varchar(36) DEFAULT NULL,
  `medicalRecordId` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `REL_2c2cd311e559d1a9e425de7b59` (`medicalRecordId`),
  KEY `IDX_46e6a4182e96de9d4c1bba5060` (`tenantId`),
  KEY `FK_13c2e57cb81b44f062ba24df57d` (`patientId`),
  KEY `FK_0c1af27b469cb8dca420c160d65` (`doctorId`),
  CONSTRAINT `FK_0c1af27b469cb8dca420c160d65` FOREIGN KEY (`doctorId`) REFERENCES `users` (`id`),
  CONSTRAINT `FK_13c2e57cb81b44f062ba24df57d` FOREIGN KEY (`patientId`) REFERENCES `patient` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_2c2cd311e559d1a9e425de7b597` FOREIGN KEY (`medicalRecordId`) REFERENCES `medical_record` (`id`),
  CONSTRAINT `FK_46e6a4182e96de9d4c1bba50604` FOREIGN KEY (`tenantId`) REFERENCES `tenant` (`id`) ON DELETE CASCADE
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: audit_logs
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `audit_logs` (
  `id` varchar(36) NOT NULL,
  `tenantId` varchar(255) DEFAULT NULL,
  `userId` varchar(255) DEFAULT NULL,
  `userEmail` varchar(255) DEFAULT NULL,
  `action` varchar(255) NOT NULL,
  `method` varchar(255) DEFAULT NULL,
  `path` varchar(255) DEFAULT NULL,
  `resource` varchar(255) DEFAULT NULL,
  `metadata` json DEFAULT NULL,
  `ip` varchar(255) DEFAULT NULL,
  `userAgent` varchar(255) DEFAULT NULL,
  `level` enum('INFO', 'WARNING', 'CRITICAL') NOT NULL DEFAULT 'INFO',
  `createdAt` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`id`),
  KEY `IDX_889633a4291bcb0bf4680fff23` (`tenantId`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: business_profiles
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `business_profiles` (
  `code` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text,
  PRIMARY KEY (`code`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: marketplace_modules
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `marketplace_modules` (
  `code` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `category` enum('CORE', 'ADDON', 'PLUGIN') NOT NULL DEFAULT 'ADDON',
  `price` decimal(10, 2) NOT NULL DEFAULT '0.00',
  `description` text,
  `dependencies` json DEFAULT NULL,
  `terms_url` varchar(255) DEFAULT NULL,
  `isActive` tinyint NOT NULL DEFAULT '1',
  PRIMARY KEY (`code`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: medical_record
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `medical_record` (
  `id` varchar(36) NOT NULL,
  `date` date NOT NULL,
  `title` varchar(255) NOT NULL,
  `notes` text,
  `steps` text,
  `attachments` text,
  `data` text,
  `createdAt` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `patientId` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_b53c9d9d9741bac9726574f34f7` (`patientId`),
  CONSTRAINT `FK_b53c9d9d9741bac9726574f34f7` FOREIGN KEY (`patientId`) REFERENCES `patient` (`id`) ON DELETE CASCADE
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: patient
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `patient` (
  `id` varchar(36) NOT NULL,
  `tenantId` varchar(36) DEFAULT NULL,
  `internalId` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `dni` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `occupation` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `birthDate` date DEFAULT NULL,
  `status` enum('DRAFT', 'READY', 'ACTIVE') NOT NULL DEFAULT 'DRAFT',
  `firstConsultationDate` date DEFAULT NULL,
  `diagnostico` text,
  `tratamiento` text,
  `antecedentes` text,
  `evaluation` text,
  `data` text,
  `other_info` text,
  `createdAt` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`id`),
  UNIQUE KEY `IDX_a15c4cc6bb6d77fa8bd1cf9f37` (`tenantId`, `internalId`),
  CONSTRAINT `FK_a070781d9d4fafa41409aad6585` FOREIGN KEY (`tenantId`) REFERENCES `tenant` (`id`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: subscription_plans
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `subscription_plans` (
  `code` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price_monthly` decimal(10, 2) NOT NULL DEFAULT '0.00',
  `price_annual` decimal(10, 2) NOT NULL DEFAULT '0.00',
  `profileCode` varchar(255) NOT NULL,
  PRIMARY KEY (`code`),
  KEY `FK_5b37ff95983fff12bf06e9b14e6` (`profileCode`),
  CONSTRAINT `FK_5b37ff95983fff12bf06e9b14e6` FOREIGN KEY (`profileCode`) REFERENCES `business_profiles` (`code`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: subscriptions
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `subscriptions` (
  `id` varchar(36) NOT NULL,
  `status` enum('TRIAL', 'ACTIVE', 'CANCELLED', 'PAST_DUE') NOT NULL DEFAULT 'TRIAL',
  `startDate` timestamp NULL DEFAULT NULL,
  `endDate` timestamp NULL DEFAULT NULL,
  `planDetails` json NOT NULL,
  `createdAt` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updatedAt` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  `tenantId` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_0c5fe8e5f9f4dd4a8c0134abc9c` (`tenantId`),
  CONSTRAINT `FK_0c5fe8e5f9f4dd4a8c0134abc9c` FOREIGN KEY (`tenantId`) REFERENCES `tenant` (`id`) ON DELETE CASCADE
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: tenant
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `tenant` (
  `id` varchar(36) NOT NULL,
  `name` varchar(255) NOT NULL,
  `industry` varchar(255) DEFAULT NULL,
  `slug` varchar(255) NOT NULL,
  `config` json NOT NULL,
  `status` enum('ACTIVE', 'SUSPENDED', 'DEBT') NOT NULL DEFAULT 'ACTIVE',
  `isActive` tinyint NOT NULL DEFAULT '1',
  `createdAt` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updatedAt` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`id`),
  UNIQUE KEY `IDX_abfd243f7bd832e806d19c5a91` (`slug`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: tenant_modules
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `tenant_modules` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenantId` varchar(255) NOT NULL,
  `status` enum('ACTIVE', 'CANCELLED', 'PAST_DUE') NOT NULL DEFAULT 'ACTIVE',
  `usage_status` enum('ACTIVE', 'CONSUMED', 'EXPIRED') NOT NULL DEFAULT 'ACTIVE',
  `valid_until` timestamp NULL DEFAULT NULL,
  `expires_at` date DEFAULT NULL,
  `trialEndsAt` date DEFAULT NULL,
  `moduleCode` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_54b5bb2fadb6ada4fe57a9e2701` (`tenantId`),
  KEY `FK_775b0266fb2f390b11a2a2411a3` (`moduleCode`),
  CONSTRAINT `FK_54b5bb2fadb6ada4fe57a9e2701` FOREIGN KEY (`tenantId`) REFERENCES `tenant` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_775b0266fb2f390b11a2a2411a3` FOREIGN KEY (`moduleCode`) REFERENCES `marketplace_modules` (`code`)
) ENGINE = InnoDB AUTO_INCREMENT = 4 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: users
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `users` (
  `id` varchar(36) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `role` enum(
  'SUPER_ADMIN',
  'TENANT_ADMIN',
  'STAFF',
  'DOCTOR',
  'PATIENT'
  ) NOT NULL DEFAULT 'STAFF',
  `isActive` tinyint NOT NULL DEFAULT '1',
  `tenantId` varchar(255) DEFAULT NULL,
  `createdAt` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updatedAt` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`id`),
  UNIQUE KEY `IDX_97672ac88f789774dd47f7c8be` (`email`),
  KEY `FK_c58f7e88c286e5e3478960a998b` (`tenantId`),
  CONSTRAINT `FK_c58f7e88c286e5e3478960a998b` FOREIGN KEY (`tenantId`) REFERENCES `tenant` (`id`) ON DELETE CASCADE
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: appointments
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: audit_logs
# ------------------------------------------------------------

INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '01e2b26c-5e8c-4b84-a2dc-b4efe9906bcd',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 02:47:53.050907'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '020c498e-2cb9-43c4-9a07-04ce15e58d1d',
    '00000000-0000-0000-0000-000000000000',
    '00000000-0000-0000-0000-000000000001',
    'superadmin@alegapp.com',
    'POST MARKETPLACE',
    'POST',
    '/marketplace/modules',
    'marketplace',
    '{\"code\": \"mod_marketing\", \"name\": \"Marketing CRM\", \"price\": 19.99, \"description\": \"CampaÃ±as Email/WhatsApp y Lead Scoring.\", \"dependencies\": [\"core-std\"]}',
    '::ffff:127.0.0.1',
    'node',
    'INFO',
    '2026-02-10 23:52:48.339615'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '052749a8-d033-4269-b966-5ba8570cf28b',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'node',
    'INFO',
    '2026-02-12 01:59:54.650252'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '05dce50a-f5d7-4f6c-93c7-775dce5c77fa',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'node',
    'INFO',
    '2026-02-12 02:05:00.651458'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '0686af74-3620-417d-8d93-86a9f8202054',
    NULL,
    'SYSTEM',
    'sara@elmundodesara.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"sara@elmundodesara.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 02:48:11.659155'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '06f9105b-7d18-45b9-a720-9bbf4b0f94f6',
    NULL,
    'SYSTEM',
    'veterinaria@drpets.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"veterinaria@drpets.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-12 01:52:45.320483'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '073808ea-8e85-474a-883f-dd9009096d51',
    NULL,
    'SYSTEM',
    'events@aspeten.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"events@aspeten.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 02:48:19.031619'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '076d8d01-2e79-4a80-85e4-df69ae9031ed',
    '00000000-0000-0000-0000-000000000000',
    '00000000-0000-0000-0000-000000000001',
    'superadmin@alegapp.com',
    'POST TENANTS',
    'POST',
    '/tenants',
    'tenants',
    '{\"name\": \"Solderma Instituto DermatolÃ³gico\", \"slug\": \"clinica-solderma\", \"config\": {\"theme\": {\"radius\": \"0.5rem\", \"logoUrl\": \"https://placehold.co/200x200/3B82F6/white?text=Solderma\", \"primary\": \"#3B82F6\"}, \"app_mode\": \"CLINICAL\", \"terminology\": {\"record\": \"Historia\", \"patient\": \"Paciente\", \"eval_section\": \"EvaluaciÃ³n DermatolÃ³gica\"}, \"active_modules\": [\"core-std\", \"util_importer\"]}, \"industry\": \"CLINICAL\", \"adminEmail\": \"administradora@solderma.com\"}',
    '::ffff:127.0.0.1',
    'node',
    'INFO',
    '2026-02-10 23:52:54.275039'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '07e4ddbb-ace0-47f0-98c8-be8d60355982',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-12 01:04:33.782206'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '08af0ad7-7618-4902-a18a-64119ce02678',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'node',
    'INFO',
    '2026-02-12 03:58:33.161488'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '092c276d-6192-42fa-ba42-3562efa24886',
    '00000000-0000-0000-0000-000000000000',
    '00000000-0000-0000-0000-000000000001',
    'superadmin@alegapp.com',
    'POST TENANTS',
    'POST',
    '/tenants',
    'tenants',
    '{\"name\": \"Dr. Pets Veterinaria\", \"slug\": \"dr-pets\", \"config\": {\"theme\": {\"radius\": \"1rem\", \"logoUrl\": \"https://placehold.co/200x200/10B981/white?text=Dr+Pets\", \"primary\": \"#10B981\"}, \"app_mode\": \"VET\", \"terminology\": {\"owner\": \"Propietario\", \"record\": \"Ficha MÃ©dica\", \"patient\": \"Mascota\", \"eval_section\": \"Triaje Veterinario\"}, \"active_modules\": [\"core-std\", \"mod_vet\"]}, \"industry\": \"VET\", \"adminEmail\": \"veterinaria@drpets.com\"}',
    '::ffff:127.0.0.1',
    'node',
    'INFO',
    '2026-02-10 23:52:54.891998'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '0a1b767c-5a40-4689-bf27-11c3aa085f18',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-12 01:04:33.779827'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '0af58dc0-4f16-438a-8771-81536a774a89',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'node',
    'INFO',
    '2026-02-12 04:10:53.561005'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '0b361077-76ef-4ce8-990d-bb7419693964',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'node',
    'INFO',
    '2026-02-12 03:56:50.147346'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '0c5b6c24-3f75-4e62-a47d-f18b6c7be654',
    '00000000-0000-0000-0000-000000000000',
    '00000000-0000-0000-0000-000000000001',
    'superadmin@alegapp.com',
    'POST MARKETPLACE',
    'POST',
    '/marketplace/modules',
    'marketplace',
    '{\"code\": \"mod_financial\", \"name\": \"Finanzas\", \"price\": 29.99, \"description\": \"FacturaciÃ³n, Caja Chica, Reportes Financieros.\", \"dependencies\": [\"core-std\"]}',
    '::ffff:127.0.0.1',
    'node',
    'INFO',
    '2026-02-10 23:52:48.283636'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '0cc00635-d441-4dee-80f2-35b39191d95b',
    NULL,
    'SYSTEM',
    'veterinaria@drpets.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"veterinaria@drpets.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 03:19:09.750018'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '0e70b1e8-d516-4135-899f-fc39821a384f',
    NULL,
    'SYSTEM',
    'superadmin@alegapp.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"superadmin@alegapp.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-12 00:59:08.658987'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '0ec2c8c3-7e73-4434-ba50-3346616f04d2',
    NULL,
    'SYSTEM',
    'sara@elmundodesara.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"sara@elmundodesara.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-12 01:05:15.703111'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '0fee6601-975d-4109-8400-7127672d304c',
    NULL,
    'SYSTEM',
    'veterinaria@drpets.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"veterinaria@drpets.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 03:13:32.763754'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '0ff0a50c-305c-4d6c-995e-5ddf65a42c44',
    NULL,
    'SYSTEM',
    'superadmin@alegapp.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"superadmin@alegapp.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 02:27:16.023249'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '1227bc07-074c-495c-b8f0-ce878d1ef489',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'node',
    'INFO',
    '2026-02-12 02:05:00.627464'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '1376ad4d-f80f-46e2-b58b-aa6b041a1082',
    NULL,
    'SYSTEM',
    'superadmin@alegapp.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"superadmin@alegapp.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 02:27:15.997169'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '14748836-80a2-4559-86eb-5c2750a662c2',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-12 04:15:20.353374'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '19233964-e398-46c0-b2a6-9bbea18bc463',
    NULL,
    'SYSTEM',
    'events@aspeten.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"events@aspeten.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 02:32:26.212772'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '1999fbac-58eb-49aa-b5a7-68ea44d5629f',
    '00000000-0000-0000-0000-000000000000',
    '00000000-0000-0000-0000-000000000001',
    'superadmin@alegapp.com',
    'POST TENANTS',
    'POST',
    '/tenants',
    'tenants',
    '{\"name\": \"Aspeten Eventos Corporativos\", \"slug\": \"aspeten-events\", \"config\": {\"theme\": {\"radius\": \"0.5rem\", \"logoUrl\": \"https://placehold.co/200x200/EC4899/white?text=Aspeten\", \"primary\": \"#EC4899\"}, \"app_mode\": \"EVENTS\", \"terminology\": {\"record\": \"Check-in\", \"patient\": \"Asistente\", \"eval_section\": \"Datos del Stand\"}, \"active_modules\": [\"core-std\", \"mod_marketing\"]}, \"industry\": \"EVENTS\", \"adminEmail\": \"events@aspeten.com\"}',
    '::ffff:127.0.0.1',
    'node',
    'INFO',
    '2026-02-10 23:52:56.521829'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '1aec0a87-54ff-48ff-9fef-997186aa01cb',
    NULL,
    'SYSTEM',
    'sara@elmundodesara.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"sara@elmundodesara.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 02:32:17.323129'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '1ca094b3-c359-4722-aafe-19b011afecd6',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 03:13:40.025939'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '1d221643-b2f1-4d94-b7ee-0e08c64f02e5',
    NULL,
    'SYSTEM',
    'superadmin@alegapp.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"superadmin@alegapp.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-10 17:46:42.699359'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '1d7c8a10-3ade-4023-b779-7f41fbd4fb6d',
    NULL,
    'SYSTEM',
    'veterinaria@drpets.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"veterinaria@drpets.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 02:48:47.541326'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '1e24fd37-d3ba-4e55-8933-ce78db00d4c1',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'node',
    'INFO',
    '2026-02-12 01:59:31.831852'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '201a584e-c6f0-49d9-93ce-9909e767b24e',
    NULL,
    'SYSTEM',
    'veterinaria@drpets.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"veterinaria@drpets.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-12 01:10:51.941374'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '22c716b6-2e42-4e0a-a106-b7198c6ab65f',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-12 01:06:12.611089'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '2538ca5f-d87c-462c-b755-e4ac7a0d8948',
    NULL,
    'SYSTEM',
    'sara@elmundodesara.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"sara@elmundodesara.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-12 00:59:40.668501'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '26c6e409-2a85-4891-bef7-e128e7f2a3cb',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 02:29:55.771676'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '27dbbb46-07e6-4441-8d14-e2107ba769e7',
    '00000000-0000-0000-0000-000000000000',
    '00000000-0000-0000-0000-000000000001',
    'superadmin@alegapp.com',
    'POST TENANTS',
    'POST',
    '/tenants',
    'tenants',
    '{\"name\": \"Solderma Instituto DermatolÃ³gico\", \"slug\": \"clinica-solderma\", \"config\": {\"theme\": {\"radius\": \"0.5rem\", \"logoUrl\": \"https://placehold.co/200x200/3B82F6/white?text=Solderma\", \"primary\": \"#3B82F6\"}, \"app_mode\": \"CLINICAL\", \"terminology\": {\"record\": \"Historia\", \"patient\": \"Paciente\", \"eval_section\": \"EvaluaciÃ³n DermatolÃ³gica\"}, \"active_modules\": [\"core-std\", \"util_importer\"]}, \"industry\": \"CLINICAL\", \"adminEmail\": \"administradora@solderma.com\"}',
    '::ffff:127.0.0.1',
    'node',
    'INFO',
    '2026-02-10 23:52:54.276550'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '298687c3-34d4-4525-9abc-a105bdd80008',
    NULL,
    'SYSTEM',
    'sara@elmundodesara.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"sara@elmundodesara.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 01:41:52.680369'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '2a256241-edb8-4002-815b-1f673df807f3',
    NULL,
    'SYSTEM',
    'veterinaria@drpets.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"veterinaria@drpets.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 02:32:11.231138'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '2b711f0e-f23f-4742-83e3-fb3f9ded1746',
    NULL,
    'SYSTEM',
    'superadmin@alegapp.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"superadmin@alegapp.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-12 01:34:16.583751'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '2b996b30-af50-49fd-ba27-e82ebb2ed21b',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'node',
    'INFO',
    '2026-02-12 03:59:40.387420'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '2baa449a-eb65-48fe-b3a8-69c2f8d64b6c',
    NULL,
    'SYSTEM',
    'superadmin@alegapp.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"superadmin@alegapp.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-10 17:46:42.675967'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '2ecbd51e-c8f6-4c62-b423-f879b91f26ac',
    NULL,
    'SYSTEM',
    'superadmin@alegapp.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"superadmin@alegapp.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 03:13:20.824165'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '309eb275-611d-4b16-8bca-db5408dfc7d2',
    NULL,
    'SYSTEM',
    'superadmin@alegapp.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"superadmin@alegapp.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 01:39:54.858862'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '312688ca-c708-4746-98b5-b8bb66e60b01',
    NULL,
    'SYSTEM',
    'veterinaria@drpets.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"veterinaria@drpets.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 02:48:03.937876'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '31c2418c-4d5c-4482-830f-a38575f1d26c',
    NULL,
    'SYSTEM',
    'sara@elmundodesara.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"sara@elmundodesara.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 02:48:11.657823'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '329b8240-4253-495a-b342-0b48d4e7dd52',
    '00000000-0000-0000-0000-000000000000',
    '00000000-0000-0000-0000-000000000001',
    'superadmin@alegapp.com',
    'POST TENANTS',
    'POST',
    '/tenants',
    'tenants',
    '{\"name\": \"Dr. Pets Veterinaria\", \"slug\": \"dr-pets\", \"config\": {\"theme\": {\"radius\": \"1rem\", \"logoUrl\": \"https://placehold.co/200x200/10B981/white?text=Dr+Pets\", \"primary\": \"#10B981\"}, \"app_mode\": \"VET\", \"terminology\": {\"owner\": \"Propietario\", \"record\": \"Ficha MÃ©dica\", \"patient\": \"Mascota\", \"eval_section\": \"Triaje Veterinario\"}, \"active_modules\": [\"core-std\", \"mod_vet\"]}, \"industry\": \"VET\", \"adminEmail\": \"veterinaria@drpets.com\"}',
    '::ffff:127.0.0.1',
    'node',
    'INFO',
    '2026-02-10 23:52:54.893584'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '32b493e9-704c-43c4-a392-611e3d6a8778',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-12 01:12:41.017903'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '340331cd-9b46-42b3-a088-14f979a75098',
    NULL,
    'SYSTEM',
    'events@aspeten.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"events@aspeten.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-12 01:04:02.486394'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '383fe814-84d2-4887-b2bc-e0669af56f53',
    '00000000-0000-0000-0000-000000000000',
    '00000000-0000-0000-0000-000000000001',
    'superadmin@alegapp.com',
    'POST MARKETPLACE',
    'POST',
    '/marketplace/modules',
    'marketplace',
    '{\"code\": \"core-std\", \"name\": \"Standard Core\", \"price\": 0, \"description\": \"Pacientes, Citas, Dashboard Base.\", \"dependencies\": []}',
    '::ffff:127.0.0.1',
    'node',
    'INFO',
    '2026-02-10 23:52:48.156734'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '397029fb-2465-4e98-a767-0af4aedef88d',
    NULL,
    'SYSTEM',
    'superadmin@alegapp.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"superadmin@alegapp.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-10 23:36:31.297848'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '3a895ff0-6e7f-47e3-836d-66af3b1f2c84',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 02:47:53.048090'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '3a9e8b53-7c6e-4c55-97d5-6f2c0bc11816',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 03:13:40.027739'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '3ab3e6cc-fea9-49d4-a960-2d7239bd886e',
    '00000000-0000-0000-0000-000000000000',
    '00000000-0000-0000-0000-000000000001',
    'superadmin@alegapp.com',
    'POST TENANTS',
    'POST',
    '/tenants',
    'tenants',
    '{\"name\": \"Aspeten Eventos Corporativos\", \"slug\": \"aspeten-events\", \"config\": {\"theme\": {\"radius\": \"0.5rem\", \"logoUrl\": \"https://placehold.co/200x200/EC4899/white?text=Aspeten\", \"primary\": \"#EC4899\"}, \"app_mode\": \"EVENTS\", \"terminology\": {\"record\": \"Check-in\", \"patient\": \"Asistente\", \"eval_section\": \"Datos del Stand\"}, \"active_modules\": [\"core-std\", \"mod_marketing\"]}, \"industry\": \"EVENTS\", \"adminEmail\": \"events@aspeten.com\"}',
    '::ffff:127.0.0.1',
    'node',
    'INFO',
    '2026-02-10 23:52:56.522844'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '3b8ada62-81e8-470d-a18b-c81b8edaccaf',
    NULL,
    'SYSTEM',
    'veterinaria@drpets.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"veterinaria@drpets.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 03:15:18.151671'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '3d25a0b0-0a63-4dcf-9dc6-964a6cfdb7b7',
    NULL,
    'SYSTEM',
    'sara@elmundodesara.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"sara@elmundodesara.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 01:55:18.240984'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '4075b182-27e5-40b5-acc0-de40cc024d85',
    NULL,
    'SYSTEM',
    'superadmin@alegapp.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"superadmin@alegapp.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 01:54:54.158731'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '42226632-fb45-4b07-96c7-58ab7e04a979',
    NULL,
    'SYSTEM',
    'events@aspeten.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"events@aspeten.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 02:48:19.033441'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '42622038-c70c-49d8-9e25-9ffd6f6ae535',
    '87b6ee14-4b49-4a44-873b-72d70d5a8344',
    '5acca214-8d8f-4510-a02a-8ccfef2a662c',
    'administradora@solderma.com',
    'POST MARKETPLACE',
    'POST',
    '/marketplace/subscribe/mod_appointments',
    'marketplace',
    '{}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-12 01:49:56.067744'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '427bc62a-d4d3-4d00-9b1a-194649eb9418',
    '00000000-0000-0000-0000-000000000000',
    '00000000-0000-0000-0000-000000000001',
    'superadmin@alegapp.com',
    'POST MARKETPLACE',
    'POST',
    '/marketplace/modules',
    'marketplace',
    '{\"code\": \"mod_vet\", \"name\": \"Pack Veterinario\", \"price\": 0, \"description\": \"Historia ClÃ­nica Vet, Razas y Vacunas.\", \"dependencies\": [\"core-std\"]}',
    '::ffff:127.0.0.1',
    'node',
    'INFO',
    '2026-02-10 23:52:48.390177'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '430cfd7a-5be9-427d-a5a2-2e8bf1aef93c',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 03:16:04.432086'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '43289665-35fb-4e47-bfbd-4b62ac011642',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-12 04:15:20.338061'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '4332b04e-0825-4679-9caa-4df93c4b45a5',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'node',
    'INFO',
    '2026-02-12 04:10:53.562277'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '44e01041-93c6-49f3-8e0d-231c0c12ba87',
    NULL,
    'SYSTEM',
    'events@aspeten.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"events@aspeten.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-12 00:59:51.244291'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '4599f5e6-d805-4fa3-8e4b-821350fb6eeb',
    NULL,
    'SYSTEM',
    'events@aspeten.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"events@aspeten.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-12 01:04:02.480953'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '45ba3aa7-9233-4f28-8f56-cd3ba376abba',
    '00000000-0000-0000-0000-000000000000',
    '00000000-0000-0000-0000-000000000001',
    'superadmin@alegapp.com',
    'POST TENANTS',
    'POST',
    '/tenants',
    'tenants',
    '{\"name\": \"El Mundo de Sara\", \"slug\": \"el-mundo-de-sara\", \"config\": {\"theme\": {\"radius\": \"0rem\", \"logoUrl\": \"https://placehold.co/200x200/8B5CF6/white?text=El+Mundo+de+Sara\", \"primary\": \"#8B5CF6\"}, \"app_mode\": \"CRAFT\", \"terminology\": {\"record\": \"Proyecto\", \"patient\": \"Alumna\", \"eval_section\": \"Detalles del Kit\"}, \"active_modules\": [\"core-std\", \"mod_logistics\"]}, \"industry\": \"CRAFT\", \"adminEmail\": \"sara@elmundodesara.com\"}',
    '::ffff:127.0.0.1',
    'node',
    'INFO',
    '2026-02-10 23:52:55.593626'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '468e7073-7d3e-40f0-a202-778abbefac01',
    NULL,
    'SYSTEM',
    'veterinaria@drpets.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"veterinaria@drpets.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-12 01:51:12.454761'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '475f1d99-f568-4c32-97a5-8bb2c7e59e53',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 02:32:48.799896'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '49216af4-c751-4253-b5b7-3b5f0bcf2607',
    '00000000-0000-0000-0000-000000000000',
    '00000000-0000-0000-0000-000000000001',
    'superadmin@alegapp.com',
    'POST MARKETPLACE',
    'POST',
    '/marketplace/modules',
    'marketplace',
    '{\"code\": \"util_importer\", \"name\": \"Migrador Excel\", \"price\": 0, \"description\": \"Herramienta de carga masiva de datos.\", \"dependencies\": [\"core-std\"]}',
    '::ffff:127.0.0.1',
    'node',
    'INFO',
    '2026-02-10 23:52:48.486629'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '4a4b37a8-9f5c-4ee8-9d8d-b52d19573497',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-12 01:14:41.770984'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '4ba990a1-640d-4b36-9fb8-c2b222704bba',
    NULL,
    'SYSTEM',
    'veterinaria@drpets.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"veterinaria@drpets.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 01:55:09.817520'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '4c03d368-0910-42ba-b309-fb4258cb6acd',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'node',
    'INFO',
    '2026-02-12 04:10:15.753933'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '4d03a139-4aac-4888-9714-2fb8c4987591',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'node',
    'INFO',
    '2026-02-12 02:05:58.497028'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '4d913498-2238-4b61-a8ce-e26a217b0964',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'node',
    'INFO',
    '2026-02-12 03:56:29.792493'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '4db55ca4-9c1c-48b8-a3ad-73760789a0dd',
    NULL,
    'SYSTEM',
    'sara@elmundodesara.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"sara@elmundodesara.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 02:48:38.667813'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '4e28c810-2dcf-45c2-b8a7-22efddcc585a',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 03:13:47.532026'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '4fb5a8ef-4c68-4bae-b0d4-39d5bc7f432b',
    '00000000-0000-0000-0000-000000000000',
    '00000000-0000-0000-0000-000000000001',
    'superadmin@alegapp.com',
    'POST MARKETPLACE',
    'POST',
    '/marketplace/modules',
    'marketplace',
    '{\"code\": \"core-std\", \"name\": \"Standard Core\", \"price\": 0, \"description\": \"Pacientes, Citas, Dashboard Base.\", \"dependencies\": []}',
    '::ffff:127.0.0.1',
    'node',
    'INFO',
    '2026-02-10 23:52:48.159780'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '52c3e30f-b00d-4f51-ac25-c87ddb3a124b',
    '87b6ee14-4b49-4a44-873b-72d70d5a8344',
    NULL,
    'administradora@solderma.com',
    'MARKETPLACE_SUBSCRIBE',
    NULL,
    NULL,
    NULL,
    '{\"price\": \"15.00\", \"module\": \"mod_appointments\", \"entityId\": \"87b6ee14-4b49-4a44-873b-72d70d5a8344\"}',
    NULL,
    NULL,
    'INFO',
    '2026-02-12 01:49:56.024115'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '52dd18cc-9bef-45a2-832c-8ee589f06662',
    NULL,
    'SYSTEM',
    'events@aspeten.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"events@aspeten.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-12 01:05:31.231213'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '52ec197d-3b0b-4868-bf72-5f2f78f344bc',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'node',
    'INFO',
    '2026-02-12 04:10:15.752605'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '597ebf6c-36dc-40b7-8488-14e87b7f998e',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-10 23:53:08.864737'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '5aa61130-6a34-48f3-9c99-3f98abb76e32',
    NULL,
    'SYSTEM',
    'superadmin@alegapp.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"superadmin@alegapp.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-12 00:59:08.626776'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '5b061529-067a-4322-b199-364ff8d32c08',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 03:13:47.530522'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '5b184f56-c38f-4296-9b73-49d02f689079',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'node',
    'INFO',
    '2026-02-12 03:58:33.160100'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '5bbe2a1c-7b67-40a4-8b08-3fe15c75a45d',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'node',
    'INFO',
    '2026-02-12 02:05:22.587298'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '5caf5e3a-a9b5-429b-bf9f-44e80ddbae64',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'node',
    'INFO',
    '2026-02-12 04:10:14.831110'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '5eb9f533-afc7-4a41-8969-25c0fbc556f3',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'node',
    'INFO',
    '2026-02-12 03:59:40.389204'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '5f0a1ed0-ebbe-4155-8006-e850ea4e8ace',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'node',
    'INFO',
    '2026-02-12 03:56:50.155723'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '60ca4fdf-4006-4677-8c7b-7dc08c97b0f5',
    NULL,
    'SYSTEM',
    'superadmin@alegapp.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"superadmin@alegapp.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 03:16:25.406945'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '60d24aa0-867d-4231-8b56-ed81c390b9e4',
    NULL,
    'SYSTEM',
    'sara@elmundodesara.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"sara@elmundodesara.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 02:32:33.808296'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '62e4fa12-f370-4e6a-8b74-9333b035caf6',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'node',
    'INFO',
    '2026-02-12 03:59:51.985466'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '647831e3-2335-4dcf-b83b-d9b4f82fa7f5',
    NULL,
    'SYSTEM',
    'sara@elmundodesara.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"sara@elmundodesara.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 02:32:17.325077'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '64e2bdb6-75e8-4489-b5cc-fc04ac689c56',
    NULL,
    'SYSTEM',
    'sara@elmundodesara.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"sara@elmundodesara.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 02:48:38.685672'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '6625e42f-62cf-4ffb-a162-b6212c53d991',
    NULL,
    'SYSTEM',
    'veterinaria@drpets.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"veterinaria@drpets.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 03:13:32.766541'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '668a6a26-2e24-4b08-988c-5250fe8546fa',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 03:13:25.934310'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '672a1b1e-8140-4665-8361-db1785ab037d',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 02:32:43.055640'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '6897c41b-1930-4c78-aa89-69e4488f5c51',
    NULL,
    'SYSTEM',
    'superadmin@alegapp.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"superadmin@alegapp.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 02:47:46.066187'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '6a8f891c-e1c7-416b-a347-eae072838963',
    '00000000-0000-0000-0000-000000000000',
    '00000000-0000-0000-0000-000000000001',
    'superadmin@alegapp.com',
    'POST MARKETPLACE',
    'POST',
    '/marketplace/modules',
    'marketplace',
    '{\"code\": \"util_importer\", \"name\": \"Migrador Excel\", \"price\": 0, \"description\": \"Herramienta de carga masiva de datos.\", \"dependencies\": [\"core-std\"]}',
    '::ffff:127.0.0.1',
    'node',
    'INFO',
    '2026-02-10 23:52:48.489192'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '6afe460a-9662-4412-ba7b-9cfd1fcc65a0',
    NULL,
    'SYSTEM',
    'veterinaria@drpets.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"veterinaria@drpets.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-12 00:59:36.710970'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '6b244961-380b-4ed3-9d15-e241a75f5f22',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'node',
    'INFO',
    '2026-02-12 03:59:10.043568'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '6b7d574a-39dd-432f-b9fa-d62e890d87ea',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 02:32:43.053999'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '6ba449fd-8f68-41bb-96b6-909e9258e986',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 01:55:02.131873'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '6d37abce-d037-4091-8456-e96d6a5b450c',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'node',
    'INFO',
    '2026-02-12 02:05:58.471808'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '71c08175-8472-4c9f-b955-e9e6479401b6',
    NULL,
    'SYSTEM',
    'superadmin@alegapp.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"superadmin@alegapp.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-12 01:34:16.593611'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '7388ea5c-df8a-4e26-84c4-2c890536c903',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'node',
    'INFO',
    '2026-02-12 03:34:01.478023'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '73c5ca30-0541-410f-ad92-f92c3a92a8f3',
    NULL,
    'SYSTEM',
    'sara@elmundodesara.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"sara@elmundodesara.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 01:55:18.243477'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '75191419-4f7a-4a1f-a9d4-ed150be6e06c',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-12 00:59:17.476551'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '75379949-b782-4b48-ab88-65d040792e08',
    NULL,
    'SYSTEM',
    'veterinaria@drpets.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"veterinaria@drpets.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 02:48:47.538802'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '75d6e359-cfcf-4f01-adae-8871e451e0bc',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 02:29:55.769899'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '76ba148e-9e3e-4f19-a38e-017bd2cd35ce',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 03:16:04.433858'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '76c100f6-282d-4a7b-853a-7381ce40171e',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 02:48:53.080237'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '773696e1-909f-41db-a3ed-3719bb68fcb1',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'node',
    'INFO',
    '2026-02-12 03:35:36.511749'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '798bc2cf-2c9e-4634-b5ae-9d83e6d93aa3',
    NULL,
    'SYSTEM',
    'events@aspeten.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"events@aspeten.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 01:55:25.912171'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '7c1926f2-31b4-4bf2-84ff-c1c0e53aa7e0',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'node',
    'INFO',
    '2026-02-12 02:03:43.967310'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '7c8bb11b-1541-4b2f-99f6-f1698b406469',
    '00000000-0000-0000-0000-000000000000',
    '00000000-0000-0000-0000-000000000001',
    'superadmin@alegapp.com',
    'POST MARKETPLACE',
    'POST',
    '/marketplace/modules',
    'marketplace',
    '{\"code\": \"mod_logistics\", \"name\": \"LogÃ­stica Pro\", \"price\": 49.99, \"description\": \"Inventario, Proveedores y Entradas/Salidas.\", \"dependencies\": [\"core-std\"]}',
    '::ffff:127.0.0.1',
    'node',
    'INFO',
    '2026-02-10 23:52:48.228760'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '7ce36cb0-cd6b-4785-9e02-7d625b23e479',
    NULL,
    'SYSTEM',
    'superadmin@alegapp.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"superadmin@alegapp.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 01:41:17.706042'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '7db8ff6e-8743-4cff-91e1-76eb680bcc96',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-12 01:49:15.070598'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '7eab5e88-baba-4345-8e3e-b57f55961440',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 03:18:49.319173'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '811628fd-dd77-48fc-a00b-b9891837f9c3',
    'f5db7585-5322-4c25-8cb6-77591f0de7cd',
    NULL,
    'veterinaria@drpets.com',
    'MARKETPLACE_SUBSCRIBE',
    NULL,
    NULL,
    NULL,
    '{\"price\": \"15.00\", \"module\": \"mod_appointments\", \"entityId\": \"f5db7585-5322-4c25-8cb6-77591f0de7cd\"}',
    NULL,
    NULL,
    'INFO',
    '2026-02-12 01:52:53.945697'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '83135910-49c8-416c-9ab7-af7adaa0ce93',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-12 01:12:41.014026'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '86480bf5-eb77-43b0-85fc-18fef3809cb9',
    '87b6ee14-4b49-4a44-873b-72d70d5a8344',
    '5acca214-8d8f-4510-a02a-8ccfef2a662c',
    'administradora@solderma.com',
    'POST MARKETPLACE',
    'POST',
    '/marketplace/subscribe/mod_appointments',
    'marketplace',
    '{}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-12 01:49:56.062736'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '87ac530c-bf1c-49ab-9542-9a7152733036',
    NULL,
    'SYSTEM',
    'veterinaria@drpets.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"veterinaria@drpets.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-12 01:52:45.318894'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '8d42a0d7-a33a-4fef-827c-7d7e6ba2083f',
    NULL,
    'SYSTEM',
    'events@aspeten.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"events@aspeten.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-12 00:59:51.247734'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '8dbfa95a-5c91-4c41-859e-32a2ee4423ad',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'node',
    'INFO',
    '2026-02-12 03:56:29.772722'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '8def79ce-e112-4209-8d23-b060dc96f106',
    NULL,
    'SYSTEM',
    'superadmin@alegapp.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"superadmin@alegapp.com\", \"password\": \"***HIDDEN***\"}',
    '::ffff:127.0.0.1',
    'node',
    'INFO',
    '2026-02-10 23:52:48.079364'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '8ef1db53-284d-4de8-8fc7-a348fecd0021',
    NULL,
    'SYSTEM',
    'veterinaria@drpets.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"veterinaria@drpets.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 03:19:09.755430'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '8fc07df8-d563-44bd-8c57-1e8e91c55dd0',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'node',
    'INFO',
    '2026-02-12 03:59:10.044781'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '90279b25-c721-49bc-adc0-4674a2438338',
    'f5db7585-5322-4c25-8cb6-77591f0de7cd',
    '247ffc50-5372-48b5-93e8-0e6e2ed9f13f',
    'veterinaria@drpets.com',
    'POST MARKETPLACE',
    'POST',
    '/marketplace/subscribe/mod_appointments',
    'marketplace',
    '{}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-12 01:52:53.981114'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '916c5066-60a8-4049-af9b-0866f6cfded9',
    NULL,
    'SYSTEM',
    'superadmin@alegapp.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"superadmin@alegapp.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-12 04:15:26.566406'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '93a32159-1f66-485c-b56e-b0324bae8d39',
    NULL,
    'SYSTEM',
    'events@aspeten.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"events@aspeten.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 01:55:25.914299'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '93af2e8c-c1e1-4165-b4da-978f4f68e55a',
    NULL,
    'SYSTEM',
    'veterinaria@drpets.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"veterinaria@drpets.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-12 01:51:12.456193'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '991153bd-4fb9-4817-96a2-d470cc8bc9c1',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 01:55:02.133443'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '9d094acb-8bc9-4675-9035-32073f752cdf',
    '00000000-0000-0000-0000-000000000000',
    '00000000-0000-0000-0000-000000000001',
    'superadmin@alegapp.com',
    'POST MARKETPLACE',
    'POST',
    '/marketplace/modules',
    'marketplace',
    '{\"code\": \"mod_marketing\", \"name\": \"Marketing CRM\", \"price\": 19.99, \"description\": \"CampaÃ±as Email/WhatsApp y Lead Scoring.\", \"dependencies\": [\"core-std\"]}',
    '::ffff:127.0.0.1',
    'node',
    'INFO',
    '2026-02-10 23:52:48.337810'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '9e085902-6c89-4cd6-86fa-516c9f53fa51',
    NULL,
    'SYSTEM',
    'superadmin@alegapp.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"superadmin@alegapp.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-10 23:36:31.295798'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    '9f71d492-5110-4e7e-9642-6c6c35b73308',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 01:40:12.903956'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'a1aa44b1-91a7-4375-a026-5556347237db',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'node',
    'INFO',
    '2026-02-12 04:10:14.403635'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'a588e9b6-a1d5-4cfe-a62f-c1e13acad469',
    NULL,
    'SYSTEM',
    'superadmin@alegapp.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"superadmin@alegapp.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 03:13:20.822804'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'a60e04df-76bf-4dd5-9a9c-fef84723f69e',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'node',
    'INFO',
    '2026-02-12 02:05:22.584792'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'a7944fa5-2a46-4859-95d3-ce8feb195c33',
    NULL,
    'SYSTEM',
    'superadmin@alegapp.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"superadmin@alegapp.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 01:42:32.459508'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'a946866a-5c64-4b2a-81d2-528e023f5b84',
    NULL,
    'SYSTEM',
    'veterinaria@drpets.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"veterinaria@drpets.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-12 01:03:54.996760'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'a9923755-3c31-4b72-9439-9dbeb1a985a6',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 01:40:12.902310'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'aa007fb9-f491-4f10-82f3-bcc88bde3713',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-12 01:03:45.594841'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'ae544823-4d98-41f6-9489-d46e3ed6038c',
    NULL,
    'SYSTEM',
    'superadmin@alegapp.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"superadmin@alegapp.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 01:39:54.856213'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'aec476a4-70ac-4ab2-bd33-d8f1af50b475',
    NULL,
    'SYSTEM',
    'events@aspeten.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"events@aspeten.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 01:42:13.415468'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'b2b0b5b3-027b-4ad6-9e40-3ed1149b1dbb',
    NULL,
    'SYSTEM',
    'superadmin@alegapp.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"superadmin@alegapp.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 02:29:52.102078'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'b32670ed-c33f-47a1-aa4e-63b5c083c816',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'node',
    'INFO',
    '2026-02-12 03:58:16.382312'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'b47d9e5d-b9ce-40b4-91fa-44b00a54ef07',
    '00000000-0000-0000-0000-000000000000',
    '00000000-0000-0000-0000-000000000001',
    'superadmin@alegapp.com',
    'POST MARKETPLACE',
    'POST',
    '/marketplace/modules',
    'marketplace',
    '{\"code\": \"mod_vet\", \"name\": \"Pack Veterinario\", \"price\": 0, \"description\": \"Historia ClÃ­nica Vet, Razas y Vacunas.\", \"dependencies\": [\"core-std\"]}',
    '::ffff:127.0.0.1',
    'node',
    'INFO',
    '2026-02-10 23:52:48.391303'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'b49faae8-47e6-44f5-9403-baf9c34fd827',
    NULL,
    'SYSTEM',
    'superadmin@alegapp.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"superadmin@alegapp.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 01:53:57.486729'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'b4d2433c-2fa1-4b14-802d-a77370496052',
    NULL,
    'SYSTEM',
    'veterinaria@drpets.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"veterinaria@drpets.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-12 01:10:51.943375'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'b69328a7-549c-4f47-a563-2acb92007ab7',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'node',
    'INFO',
    '2026-02-12 04:10:14.857819'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'b6cd8f70-dcdd-4d06-9d3f-7afa4ca5eace',
    NULL,
    'SYSTEM',
    'sara@elmundodesara.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"sara@elmundodesara.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-12 01:05:15.707059'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'b73e28c3-b003-4595-8ebb-c5cee2c3dcf2',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-12 01:03:45.596620'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'b79a07c6-ef10-44d3-9e32-655616d72ea9',
    NULL,
    'SYSTEM',
    'veterinaria@drpets.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"veterinaria@drpets.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 02:32:11.239943'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'b7fcff85-4df1-44b6-9698-43b5cd3d55ea',
    NULL,
    'SYSTEM',
    'superadmin@alegapp.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"superadmin@alegapp.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-10 23:29:37.755489'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'b906b966-2c43-4aa7-b734-6c5200ebc33e',
    NULL,
    'SYSTEM',
    'veterinaria@drpets.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"veterinaria@drpets.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 01:41:36.751971'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'b9ddd499-ce21-4b5f-be35-e614c5308f4f',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'node',
    'INFO',
    '2026-02-12 04:10:14.362254'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'ba4134da-32d5-4f88-b6a5-aaabc9734987',
    NULL,
    'SYSTEM',
    'superadmin@alegapp.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"superadmin@alegapp.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 01:42:32.462304'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'ba8bf0be-1c4b-42c9-9390-59046632a0f8',
    NULL,
    'SYSTEM',
    'veterinaria@drpets.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"veterinaria@drpets.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 03:15:18.148580'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'bb2e694e-a54a-47db-93f7-d5003ac50b6e',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'node',
    'INFO',
    '2026-02-12 01:59:54.648086'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'bc9b1c8b-7294-4bd6-bd87-dcc316792810',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-12 01:14:41.769584'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'bccb8ee0-c7c6-47ab-b730-eb85900f002b',
    NULL,
    'SYSTEM',
    'events@aspeten.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"events@aspeten.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 01:42:13.417381'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'bd87750e-1b84-486e-9b86-c1f9539a8812',
    NULL,
    'SYSTEM',
    'sara@elmundodesara.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"sara@elmundodesara.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 01:41:52.682733'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'bdaa4290-a9a5-4156-998a-588bae7bb88c',
    NULL,
    'SYSTEM',
    'superadmin@alegapp.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"superadmin@alegapp.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 02:29:52.099877'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'bdec6cf8-4200-4fb3-b85e-2fcc85d59a80',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 02:32:48.798243'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'beb5dff4-8ef1-4ad1-be11-c56b28194aa0',
    NULL,
    'SYSTEM',
    'superadmin@alegapp.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"superadmin@alegapp.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-12 04:15:26.561989'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'bec61dc2-c110-4309-aca8-e29d4ab4d3fd',
    NULL,
    'SYSTEM',
    'superadmin@alegapp.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"superadmin@alegapp.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-10 23:29:37.760466'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'c0638994-4ee5-45c5-9434-1ca8568c8916',
    NULL,
    'SYSTEM',
    'veterinaria@drpets.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"veterinaria@drpets.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 02:48:03.950953'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'c1bf486d-b299-423b-adae-bb63b1c5d49a',
    'f5db7585-5322-4c25-8cb6-77591f0de7cd',
    '247ffc50-5372-48b5-93e8-0e6e2ed9f13f',
    'veterinaria@drpets.com',
    'POST MARKETPLACE',
    'POST',
    '/marketplace/subscribe/mod_appointments',
    'marketplace',
    '{}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-12 01:52:53.982210'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'c334212a-533c-446e-bb74-55abaf43c459',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-12 00:59:17.489841'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'c3a7274b-7362-4dc0-b8d9-554c99795916',
    '00000000-0000-0000-0000-000000000000',
    '00000000-0000-0000-0000-000000000001',
    'superadmin@alegapp.com',
    'POST MARKETPLACE',
    'POST',
    '/marketplace/modules',
    'marketplace',
    '{\"code\": \"mod_logistics\", \"name\": \"LogÃ­stica Pro\", \"price\": 49.99, \"description\": \"Inventario, Proveedores y Entradas/Salidas.\", \"dependencies\": [\"core-std\"]}',
    '::ffff:127.0.0.1',
    'node',
    'INFO',
    '2026-02-10 23:52:48.229882'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'c6e09d8e-5778-41f2-b6b5-42e038bf54e5',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'node',
    'INFO',
    '2026-02-12 03:34:01.461953'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'caebf3e8-5b69-469b-87eb-6940a7eda7a2',
    NULL,
    'SYSTEM',
    'events@aspeten.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"events@aspeten.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 02:32:26.211215'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'cb2249bb-bb6d-4932-b8ed-d03b0033878e',
    NULL,
    'SYSTEM',
    'veterinaria@drpets.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"veterinaria@drpets.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-12 01:06:16.505365'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'cb39588f-81cb-4c8f-8b8d-71394fab3905',
    NULL,
    'SYSTEM',
    'veterinaria@drpets.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"veterinaria@drpets.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 02:32:39.345771'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'cd3cd88d-2551-4e55-bf9e-23bf9bfe2e94',
    NULL,
    'SYSTEM',
    'veterinaria@drpets.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"veterinaria@drpets.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 01:41:36.753689'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'cdb0abdc-a0d5-421a-b7e8-596180dfe8cd',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'node',
    'INFO',
    '2026-02-12 03:35:07.555088'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'cf06bab6-6c24-4123-85fc-fa8577010061',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 02:48:53.078472'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'cf9da7d6-61e1-4a54-b286-936e27883fe7',
    NULL,
    'SYSTEM',
    'veterinaria@drpets.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"veterinaria@drpets.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-12 01:03:54.994211'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'd11e2fdd-25f3-4ca0-bdc9-ad06338bf5c7',
    NULL,
    'SYSTEM',
    'veterinaria@drpets.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"veterinaria@drpets.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-12 01:06:16.501996'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'd3175224-c9ec-4613-82aa-4eeeb2ec0d8c',
    NULL,
    'SYSTEM',
    'sara@elmundodesara.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"sara@elmundodesara.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-12 00:59:40.643486'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'd31f577d-6430-4f6f-868e-dcc144757ba1',
    NULL,
    'SYSTEM',
    'superadmin@alegapp.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"superadmin@alegapp.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 01:53:57.489007'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'd5252c52-d067-41c7-9313-c4a1a79f9797',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-12 01:06:12.608410'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'd5c93283-9497-4e03-a4d4-64a2c903f894',
    NULL,
    'SYSTEM',
    'superadmin@alegapp.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"superadmin@alegapp.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 01:41:17.703912'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'd7c471f6-de1d-4c14-9c68-ee0148cb7e60',
    '00000000-0000-0000-0000-000000000000',
    '00000000-0000-0000-0000-000000000001',
    'superadmin@alegapp.com',
    'POST TENANTS',
    'POST',
    '/tenants',
    'tenants',
    '{\"name\": \"El Mundo de Sara\", \"slug\": \"el-mundo-de-sara\", \"config\": {\"theme\": {\"radius\": \"0rem\", \"logoUrl\": \"https://placehold.co/200x200/8B5CF6/white?text=El+Mundo+de+Sara\", \"primary\": \"#8B5CF6\"}, \"app_mode\": \"CRAFT\", \"terminology\": {\"record\": \"Proyecto\", \"patient\": \"Alumna\", \"eval_section\": \"Detalles del Kit\"}, \"active_modules\": [\"core-std\", \"mod_logistics\"]}, \"industry\": \"CRAFT\", \"adminEmail\": \"sara@elmundodesara.com\"}',
    '::ffff:127.0.0.1',
    'node',
    'INFO',
    '2026-02-10 23:52:55.592380'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'daa866d3-e2b2-4085-b1c1-82de6f7818c0',
    '87b6ee14-4b49-4a44-873b-72d70d5a8344',
    '5acca214-8d8f-4510-a02a-8ccfef2a662c',
    'administradora@solderma.com',
    'POST TENANTS',
    'POST',
    '/tenants/subscribe',
    'tenants',
    '{\"moduleCode\": \"mod_appointments\"}',
    '::1',
    'node',
    'INFO',
    '2026-02-12 02:05:59.050113'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'daebb627-e2ed-4cd6-8917-7c139350b859',
    NULL,
    'SYSTEM',
    'superadmin@alegapp.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"superadmin@alegapp.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 02:47:46.067792'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'db914ab2-658c-4806-afc0-d70ee46df27a',
    '87b6ee14-4b49-4a44-873b-72d70d5a8344',
    '5acca214-8d8f-4510-a02a-8ccfef2a662c',
    'administradora@solderma.com',
    'POST TENANTS',
    'POST',
    '/tenants/subscribe',
    'tenants',
    '{\"moduleCode\": \"mod_appointments\"}',
    '::1',
    'node',
    'INFO',
    '2026-02-12 02:05:59.043419'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'dc419c70-aea9-4c45-8e82-d7bbb1aa96f0',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 01:53:50.807720'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'de4642c2-3bff-4171-bb15-c4360f1cf1e2',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'node',
    'INFO',
    '2026-02-12 03:58:16.381168'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'e2d7986a-bfbf-4898-b625-242bddf17c41',
    NULL,
    'SYSTEM',
    'veterinaria@drpets.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"veterinaria@drpets.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 02:32:39.342635'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'e3203959-483a-4180-a142-e06b0f86f365',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'node',
    'INFO',
    '2026-02-12 01:59:31.829589'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'e35a4854-7417-4fef-b059-516024a5d84f',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'node',
    'INFO',
    '2026-02-12 03:35:07.516159'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'e412af46-b15b-44a8-b9bf-af3412f6917c',
    NULL,
    'SYSTEM',
    'veterinaria@drpets.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"veterinaria@drpets.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-12 01:05:02.390489'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'e69aca4a-18bb-4c10-ab47-4b9f98f2eb7e',
    '00000000-0000-0000-0000-000000000000',
    '00000000-0000-0000-0000-000000000001',
    'superadmin@alegapp.com',
    'POST MARKETPLACE',
    'POST',
    '/marketplace/modules',
    'marketplace',
    '{\"code\": \"mod_financial\", \"name\": \"Finanzas\", \"price\": 29.99, \"description\": \"FacturaciÃ³n, Caja Chica, Reportes Financieros.\", \"dependencies\": [\"core-std\"]}',
    '::ffff:127.0.0.1',
    'node',
    'INFO',
    '2026-02-10 23:52:48.282433'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'e83dfaf5-029d-4f3f-aa91-084058a4ce43',
    NULL,
    'SYSTEM',
    'superadmin@alegapp.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"superadmin@alegapp.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-10 23:47:25.909360'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'e84e9dd7-61e5-4cff-b6e7-cfd229660b95',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'node',
    'INFO',
    '2026-02-12 01:58:22.061586'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'e8505deb-6698-42cf-b39b-3a57d31f4576',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-12 01:49:15.069066'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'ea429452-6261-4206-a8c5-c1bf2b5e24b2',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 03:13:25.932494'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'eb901161-33f6-4c02-969f-cb7f9f0c7eb7',
    NULL,
    'SYSTEM',
    'events@aspeten.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"events@aspeten.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-12 01:05:31.229692'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'ee5165d4-23f1-4112-a5cf-0bb409f54830',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'node',
    'INFO',
    '2026-02-12 01:58:22.092207'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'ef35337e-d1ec-4ff5-827a-c1e4031929db',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 01:53:50.822147'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'f0d5d16b-ffbf-497a-9273-ea0b3a6db797',
    NULL,
    'SYSTEM',
    'superadmin@alegapp.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"superadmin@alegapp.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-10 23:47:25.907778'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'f243ad5b-bcc9-487f-bbfb-24c8a0df997a',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'node',
    'INFO',
    '2026-02-12 03:59:22.292480'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'f253ab30-ce58-4afa-8768-940e6d3badb0',
    NULL,
    'SYSTEM',
    'superadmin@alegapp.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"superadmin@alegapp.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 01:54:54.164233'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'f26428f2-5eb7-43fa-96ff-17294adcdf5a',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'node',
    'INFO',
    '2026-02-12 03:59:51.987107'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'f2c19cca-d373-420a-ba08-91652ab0f038',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'node',
    'INFO',
    '2026-02-12 03:35:36.478327'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'f32ab920-01fa-4d40-9e38-d04abb875bef',
    NULL,
    'SYSTEM',
    'superadmin@alegapp.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"superadmin@alegapp.com\", \"password\": \"***HIDDEN***\"}',
    '::ffff:127.0.0.1',
    'node',
    'INFO',
    '2026-02-10 23:52:48.078215'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'f46688f1-00b4-40f5-b680-4c21dea2eddc',
    NULL,
    'SYSTEM',
    'superadmin@alegapp.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"superadmin@alegapp.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 03:16:25.408455'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'f5202636-3858-48f1-bd44-056015e387ce',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'node',
    'INFO',
    '2026-02-12 02:03:43.963935'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'f5d1e187-1c76-4d64-ace1-7f5f58366c18',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'node',
    'INFO',
    '2026-02-12 03:59:22.291406'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'f5fd6577-7a7f-4c60-8db7-ef696deae68d',
    NULL,
    'SYSTEM',
    'veterinaria@drpets.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"veterinaria@drpets.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 01:55:09.819390'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'f6707b79-3adf-4588-8c1f-7821ad140a5d',
    NULL,
    'SYSTEM',
    'veterinaria@drpets.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"veterinaria@drpets.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-12 01:05:02.388367'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'f6db54fc-774e-4885-b9fe-ea4d2ac740e2',
    NULL,
    'SYSTEM',
    'sara@elmundodesara.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"sara@elmundodesara.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 02:32:33.810554'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'f7fb977f-8826-42ad-8fea-d3b1f8fbb1bf',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-10 23:53:08.861272'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'fc208f10-4928-47c2-8f8d-204a5ddc898b',
    NULL,
    'SYSTEM',
    'veterinaria@drpets.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"veterinaria@drpets.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-12 00:59:36.708412'
  );
INSERT INTO
  `audit_logs` (
    `id`,
    `tenantId`,
    `userId`,
    `userEmail`,
    `action`,
    `method`,
    `path`,
    `resource`,
    `metadata`,
    `ip`,
    `userAgent`,
    `level`,
    `createdAt`
  )
VALUES
  (
    'fdc71ee2-55af-4354-b833-239858104339',
    NULL,
    'SYSTEM',
    'administradora@solderma.com',
    'POST AUTH',
    'POST',
    '/auth/login',
    'auth',
    '{\"email\": \"administradora@solderma.com\", \"password\": \"***HIDDEN***\"}',
    '::1',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36',
    'INFO',
    '2026-02-11 03:18:49.320623'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: business_profiles
# ------------------------------------------------------------

INSERT INTO
  `business_profiles` (`code`, `name`, `description`)
VALUES
  (
    'PROFILE_CLINIC',
    'Clínica Médica',
    'Para centros de salud humana'
  );
INSERT INTO
  `business_profiles` (`code`, `name`, `description`)
VALUES
  (
    'PROFILE_CRAFT',
    'Emprendimiento',
    'Para negocios pequeños'
  );
INSERT INTO
  `business_profiles` (`code`, `name`, `description`)
VALUES
  (
    'PROFILE_EVENTS',
    'Gestión de Eventos',
    'Para control de accesos y stands'
  );
INSERT INTO
  `business_profiles` (`code`, `name`, `description`)
VALUES
  (
    'PROFILE_VET',
    'Clínica Veterinaria',
    'Para centros de salud animal'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: marketplace_modules
# ------------------------------------------------------------

INSERT INTO
  `marketplace_modules` (
    `code`,
    `name`,
    `category`,
    `price`,
    `description`,
    `dependencies`,
    `terms_url`,
    `isActive`
  )
VALUES
  (
    'core-std',
    'Standard Core',
    'CORE',
    0.00,
    'Pacientes, Citas, Dashboard Base.',
    '[]',
    NULL,
    1
  );
INSERT INTO
  `marketplace_modules` (
    `code`,
    `name`,
    `category`,
    `price`,
    `description`,
    `dependencies`,
    `terms_url`,
    `isActive`
  )
VALUES
  (
    'mod_appointments',
    'Gestión de Citas',
    'ADDON',
    15.00,
    'Agenda avanzada, recordatorios WhatsApp, control de asistencia.',
    NULL,
    NULL,
    1
  );
INSERT INTO
  `marketplace_modules` (
    `code`,
    `name`,
    `category`,
    `price`,
    `description`,
    `dependencies`,
    `terms_url`,
    `isActive`
  )
VALUES
  (
    'mod_financial',
    'Finanzas',
    'ADDON',
    29.99,
    'Facturación, Caja Chica, Reportes Financieros.',
    '[\"core-std\"]',
    NULL,
    1
  );
INSERT INTO
  `marketplace_modules` (
    `code`,
    `name`,
    `category`,
    `price`,
    `description`,
    `dependencies`,
    `terms_url`,
    `isActive`
  )
VALUES
  (
    'mod_logistics',
    'Logística Pro',
    'ADDON',
    49.99,
    'Inventario, Proveedores y Entradas/Salidas.',
    '[\"core-std\"]',
    NULL,
    1
  );
INSERT INTO
  `marketplace_modules` (
    `code`,
    `name`,
    `category`,
    `price`,
    `description`,
    `dependencies`,
    `terms_url`,
    `isActive`
  )
VALUES
  (
    'mod_marketing',
    'Marketing CRM',
    'ADDON',
    19.99,
    'Campañas Email/WhatsApp y Lead Scoring.',
    '[\"core-std\"]',
    NULL,
    1
  );
INSERT INTO
  `marketplace_modules` (
    `code`,
    `name`,
    `category`,
    `price`,
    `description`,
    `dependencies`,
    `terms_url`,
    `isActive`
  )
VALUES
  (
    'mod_medical_records',
    'Historias Clínicas',
    'ADDON',
    20.00,
    'Expedientes médicos completos, recetas, triaje.',
    NULL,
    NULL,
    1
  );
INSERT INTO
  `marketplace_modules` (
    `code`,
    `name`,
    `category`,
    `price`,
    `description`,
    `dependencies`,
    `terms_url`,
    `isActive`
  )
VALUES
  (
    'mod_patients',
    'Directorio de Pacientes',
    'ADDON',
    10.00,
    'Base de datos de pacientes, historia clínica digital.',
    NULL,
    NULL,
    1
  );
INSERT INTO
  `marketplace_modules` (
    `code`,
    `name`,
    `category`,
    `price`,
    `description`,
    `dependencies`,
    `terms_url`,
    `isActive`
  )
VALUES
  (
    'mod_vet',
    'Pack Veterinario',
    'CORE',
    0.00,
    'Historia Clínica Vet, Razas y Vacunas.',
    '[\"core-std\"]',
    NULL,
    1
  );
INSERT INTO
  `marketplace_modules` (
    `code`,
    `name`,
    `category`,
    `price`,
    `description`,
    `dependencies`,
    `terms_url`,
    `isActive`
  )
VALUES
  (
    'util_importer',
    'Migrador Excel',
    'PLUGIN',
    0.00,
    'Herramienta de carga masiva de datos.',
    '[\"core-std\"]',
    NULL,
    1
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: medical_record
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: patient
# ------------------------------------------------------------


# ------------------------------------------------------------
# DATA DUMP FOR TABLE: subscription_plans
# ------------------------------------------------------------

INSERT INTO
  `subscription_plans` (
    `code`,
    `name`,
    `price_monthly`,
    `price_annual`,
    `profileCode`
  )
VALUES
  (
    'PLAN_DERMA_PRO',
    'Derma Pro',
    99.00,
    990.00,
    'PROFILE_CLINIC'
  );
INSERT INTO
  `subscription_plans` (
    `code`,
    `name`,
    `price_monthly`,
    `price_annual`,
    `profileCode`
  )
VALUES
  (
    'PLAN_EMPRENDEDOR',
    'Emprendedor',
    19.00,
    190.00,
    'PROFILE_CRAFT'
  );
INSERT INTO
  `subscription_plans` (
    `code`,
    `name`,
    `price_monthly`,
    `price_annual`,
    `profileCode`
  )
VALUES
  (
    'PLAN_VET_BASIC',
    'Vet Basic',
    49.00,
    490.00,
    'PROFILE_VET'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: subscriptions
# ------------------------------------------------------------

INSERT INTO
  `subscriptions` (
    `id`,
    `status`,
    `startDate`,
    `endDate`,
    `planDetails`,
    `createdAt`,
    `updatedAt`,
    `tenantId`
  )
VALUES
  (
    '1d1ac0a5-eca5-4a63-beae-a1835003c724',
    'TRIAL',
    '2026-02-10 18:52:54',
    '2026-03-12 18:52:54',
    '{\"name\": \"TRIAL\", \"price\": 0, \"limits\": {\"users\": 5}}',
    '2026-02-10 23:52:54.134642',
    '2026-02-10 23:52:54.134642',
    '87b6ee14-4b49-4a44-873b-72d70d5a8344'
  );
INSERT INTO
  `subscriptions` (
    `id`,
    `status`,
    `startDate`,
    `endDate`,
    `planDetails`,
    `createdAt`,
    `updatedAt`,
    `tenantId`
  )
VALUES
  (
    '1fdc68d9-b17c-487a-af56-a10950994a7b',
    'TRIAL',
    '2026-02-10 18:52:55',
    '2026-03-12 18:52:55',
    '{\"name\": \"TRIAL\", \"price\": 0, \"limits\": {\"users\": 5}}',
    '2026-02-10 23:52:55.459985',
    '2026-02-10 23:52:55.459985',
    '54feb303-de46-4515-b053-a93d2fab2706'
  );
INSERT INTO
  `subscriptions` (
    `id`,
    `status`,
    `startDate`,
    `endDate`,
    `planDetails`,
    `createdAt`,
    `updatedAt`,
    `tenantId`
  )
VALUES
  (
    '8c4096f5-60ef-4c8e-ae95-37234906be68',
    'TRIAL',
    '2026-02-10 18:52:56',
    '2026-03-12 18:52:56',
    '{\"name\": \"TRIAL\", \"price\": 0, \"limits\": {\"users\": 5}}',
    '2026-02-10 23:52:56.373617',
    '2026-02-10 23:52:56.373617',
    '45251903-79ad-4a69-bc93-b1026d1d04a4'
  );
INSERT INTO
  `subscriptions` (
    `id`,
    `status`,
    `startDate`,
    `endDate`,
    `planDetails`,
    `createdAt`,
    `updatedAt`,
    `tenantId`
  )
VALUES
  (
    'fc7b6972-6204-4083-a14a-c63a9086f2bb',
    'TRIAL',
    '2026-02-10 18:52:55',
    '2026-03-12 18:52:55',
    '{\"name\": \"TRIAL\", \"price\": 0, \"limits\": {\"users\": 5}}',
    '2026-02-10 23:52:54.773533',
    '2026-02-10 23:52:54.773533',
    'f5db7585-5322-4c25-8cb6-77591f0de7cd'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: tenant
# ------------------------------------------------------------

INSERT INTO
  `tenant` (
    `id`,
    `name`,
    `industry`,
    `slug`,
    `config`,
    `status`,
    `isActive`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    '00000000-0000-0000-0000-000000000000',
    'SYSTEM ADMIN GLOBAL',
    'SYSTEM',
    'global-admin',
    '{}',
    'ACTIVE',
    1,
    '2026-02-10 17:40:00.554608',
    '2026-02-10 17:40:00.554608'
  );
INSERT INTO
  `tenant` (
    `id`,
    `name`,
    `industry`,
    `slug`,
    `config`,
    `status`,
    `isActive`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    '45251903-79ad-4a69-bc93-b1026d1d04a4',
    'ASPETEN EVENTOS CORPORATIVOS',
    'EVENTS',
    'aspeten-events',
    '{\"theme\": {\"radius\": \"0.5rem\", \"logoUrl\": \"https://placehold.co/200x200/EC4899/white?text=Aspeten\", \"primary\": \"#EC4899\"}, \"app_mode\": \"EVENTS\", \"branding\": {\"theme\": \"default\", \"logoUrl\": null}, \"industry\": \"EVENTS\", \"settings\": {\"currency\": \"USD\", \"timezone\": \"UTC\"}, \"terminology\": {\"record\": \"Check-in\", \"patient\": \"Asistente\", \"eval_section\": \"Datos del Stand\"}, \"active_modules\": [\"core-std\", \"mod_marketing\"]}',
    'ACTIVE',
    1,
    '2026-02-10 23:52:56.367828',
    '2026-02-10 23:52:56.367828'
  );
INSERT INTO
  `tenant` (
    `id`,
    `name`,
    `industry`,
    `slug`,
    `config`,
    `status`,
    `isActive`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    '54feb303-de46-4515-b053-a93d2fab2706',
    'EL MUNDO DE SARA',
    'CRAFT',
    'el-mundo-de-sara',
    '{\"theme\": {\"radius\": \"0rem\", \"logoUrl\": \"https://placehold.co/200x200/8B5CF6/white?text=El+Mundo+de+Sara\", \"primary\": \"#8B5CF6\"}, \"app_mode\": \"CRAFT\", \"branding\": {\"theme\": \"default\", \"logoUrl\": null}, \"industry\": \"CRAFT\", \"settings\": {\"currency\": \"USD\", \"timezone\": \"UTC\"}, \"terminology\": {\"record\": \"Proyecto\", \"patient\": \"Alumna\", \"eval_section\": \"Detalles del Kit\"}, \"active_modules\": [\"core-std\", \"mod_logistics\"]}',
    'ACTIVE',
    1,
    '2026-02-10 23:52:55.454375',
    '2026-02-10 23:52:55.454375'
  );
INSERT INTO
  `tenant` (
    `id`,
    `name`,
    `industry`,
    `slug`,
    `config`,
    `status`,
    `isActive`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    '87b6ee14-4b49-4a44-873b-72d70d5a8344',
    'SOLDERMA INSTITUTO DERMATOLGICO',
    'CLINICAL',
    'clinica-solderma',
    '{\"theme\": {\"radius\": \"0.5rem\", \"logoUrl\": \"https://placehold.co/200x200/3B82F6/white?text=Solderma\", \"primary\": \"#3B82F6\"}, \"app_mode\": \"CLINICAL\", \"branding\": {\"theme\": \"default\", \"logoUrl\": null}, \"industry\": \"CLINICAL\", \"settings\": {\"currency\": \"USD\", \"timezone\": \"UTC\"}, \"terminology\": {\"record\": \"Historia\", \"patient\": \"Paciente\", \"eval_section\": \"EvaluaciÃ³n DermatolÃ³gica\"}, \"active_modules\": [\"core-std\", \"util_importer\", \"mod_appointments\"]}',
    'ACTIVE',
    1,
    '2026-02-10 23:52:54.124779',
    '2026-02-12 03:35:36.776388'
  );
INSERT INTO
  `tenant` (
    `id`,
    `name`,
    `industry`,
    `slug`,
    `config`,
    `status`,
    `isActive`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'f5db7585-5322-4c25-8cb6-77591f0de7cd',
    'DR. PETS VETERINARIA',
    'VET',
    'dr-pets',
    '{\"theme\": {\"radius\": \"1rem\", \"logoUrl\": \"https://placehold.co/200x200/10B981/white?text=Dr+Pets\", \"primary\": \"#10B981\"}, \"app_mode\": \"VET\", \"branding\": {\"theme\": \"default\", \"logoUrl\": null}, \"industry\": \"VET\", \"settings\": {\"currency\": \"USD\", \"timezone\": \"UTC\"}, \"terminology\": {\"owner\": \"Propietario\", \"record\": \"Ficha MÃ©dica\", \"patient\": \"Mascota\", \"eval_section\": \"Triaje Veterinario\"}, \"active_modules\": [\"core-std\", \"mod_vet\", \"mod_appointments\"]}',
    'ACTIVE',
    1,
    '2026-02-10 23:52:54.766790',
    '2026-02-12 01:52:53.000000'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: tenant_modules
# ------------------------------------------------------------

INSERT INTO
  `tenant_modules` (
    `id`,
    `tenantId`,
    `status`,
    `usage_status`,
    `valid_until`,
    `expires_at`,
    `trialEndsAt`,
    `moduleCode`
  )
VALUES
  (
    2,
    'f5db7585-5322-4c25-8cb6-77591f0de7cd',
    'ACTIVE',
    'ACTIVE',
    NULL,
    NULL,
    NULL,
    'mod_appointments'
  );
INSERT INTO
  `tenant_modules` (
    `id`,
    `tenantId`,
    `status`,
    `usage_status`,
    `valid_until`,
    `expires_at`,
    `trialEndsAt`,
    `moduleCode`
  )
VALUES
  (
    3,
    '87b6ee14-4b49-4a44-873b-72d70d5a8344',
    'ACTIVE',
    'ACTIVE',
    NULL,
    '2030-01-01',
    NULL,
    'mod_appointments'
  );

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: users
# ------------------------------------------------------------

INSERT INTO
  `users` (
    `id`,
    `email`,
    `password`,
    `fullName`,
    `role`,
    `isActive`,
    `tenantId`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    '00000000-0000-0000-0000-000000000001',
    'superadmin@alegapp.com',
    '$2b$10$quaNb71Vusb4yv9SGoNbou75ziN21SRbB412bLf0RBW9.ekVCmBDS',
    'Super Admin',
    'SUPER_ADMIN',
    1,
    '00000000-0000-0000-0000-000000000000',
    '2026-02-10 17:40:00.676196',
    '2026-02-10 17:40:00.676196'
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password`,
    `fullName`,
    `role`,
    `isActive`,
    `tenantId`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    '247ffc50-5372-48b5-93e8-0e6e2ed9f13f',
    'veterinaria@drpets.com',
    '$2b$10$cX/ph2RrUFBRYv0fmk0NGutnt1c/8THEyF7HPtfiWSZWimgahUcqe',
    'Admin DR. PETS VETERINARIA',
    'TENANT_ADMIN',
    1,
    'f5db7585-5322-4c25-8cb6-77591f0de7cd',
    '2026-02-10 23:52:54.874389',
    '2026-02-10 23:52:54.874389'
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password`,
    `fullName`,
    `role`,
    `isActive`,
    `tenantId`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    '4ee7c7e3-9c80-4315-84c5-7b72f73af7d0',
    'events@aspeten.com',
    '$2b$10$HySDAmxeewEsh7IZnMcFWOnF2LxoFbnrJ0K0xuT0fRqWfnh/Rw7I6',
    'Admin ASPETEN EVENTOS CORPORATIVOS',
    'TENANT_ADMIN',
    1,
    '45251903-79ad-4a69-bc93-b1026d1d04a4',
    '2026-02-10 23:52:56.502910',
    '2026-02-10 23:52:56.502910'
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password`,
    `fullName`,
    `role`,
    `isActive`,
    `tenantId`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    '5acca214-8d8f-4510-a02a-8ccfef2a662c',
    'administradora@solderma.com',
    '$2b$10$3Lbrqn0.YYTvafHVuceeU.x6ozaFsYVMFp2FyFaP32HWHjgJNIX1e',
    'Admin SOLDERMA INSTITUTO DERMATOLGICO',
    'TENANT_ADMIN',
    1,
    '87b6ee14-4b49-4a44-873b-72d70d5a8344',
    '2026-02-10 23:52:54.250207',
    '2026-02-10 23:52:54.250207'
  );
INSERT INTO
  `users` (
    `id`,
    `email`,
    `password`,
    `fullName`,
    `role`,
    `isActive`,
    `tenantId`,
    `createdAt`,
    `updatedAt`
  )
VALUES
  (
    'f858ce6f-6482-40aa-8126-132e05bb62aa',
    'sara@elmundodesara.com',
    '$2b$10$euuMjDv7.h/Z5PSpqgmAV.jYPvRpnl6E1eEXk51piyA2x4srLwgXq',
    'Admin EL MUNDO DE SARA',
    'TENANT_ADMIN',
    1,
    '54feb303-de46-4515-b053-a93d2fab2706',
    '2026-02-10 23:52:55.576068',
    '2026-02-10 23:52:55.576068'
  );

/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
